-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.7.0.6850
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for abc_hospital
CREATE DATABASE IF NOT EXISTS `abc_hospital` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */;
USE `abc_hospital`;

-- Dumping structure for table abc_hospital.admins
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dumping data for table abc_hospital.admins: ~0 rows (approximately)
DELETE FROM `admins`;
INSERT INTO `admins` (`id`, `username`, `password`) VALUES
	(1, 'admin', 'admin');

-- Dumping structure for table abc_hospital.appointments
CREATE TABLE IF NOT EXISTS `appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_name` varchar(100) DEFAULT NULL,
  `contact_info` varchar(13) DEFAULT NULL,
  `doctor_name` varchar(100) DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `appointment_time` time DEFAULT NULL,
  `reason` text DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dumping data for table abc_hospital.appointments: ~7 rows (approximately)
DELETE FROM `appointments`;
INSERT INTO `appointments` (`id`, `patient_name`, `contact_info`, `doctor_name`, `appointment_date`, `appointment_time`, `reason`) VALUES
	(1, 'chamod', '0779127502', 'chamod', '2025-07-16', '15:26:00', 'hii'),
	(2, 'dasun kumara', '0779127502', 'Dr. Aravinda rathnayake ', '2025-07-08', '08:00:00', 'Checkup'),
	(4, 'Tehan Liyanage', '077 6237234', 'Dr. Thilak Rajapaksha ', '2025-07-04', '17:10:00', 'Expert care for bones, joints, fractures; restore mobility, relieve pain.\r\n'),
	(5, 'kumara dasun', '091 324424', 'Dr. Udaya Ranawaka ', '2025-07-01', '07:50:00', 'Clear, healthy skin; expert acne, eczema care; youthful, refreshed appearance.'),
	(6, 'Pubudu ranasinghe', '082 1332323', 'Dr. Kumaran Ratnam ', '2025-07-16', '19:00:00', ' child’s growth, health, vaccinations, and early issue '),
	(7, 'gunarathne kumara', '0772356483488', 'Dr. Anil Jasinghe ', '2025-07-08', '15:53:00', 'Protect vision, treat eye conditions, improve clarity, maintain lifelong eye health get advice and check up'),
	(8, 'kalhara ', '077 46545453', 'Dr. Aravinda rathnayake ', '2025-08-01', '10:20:00', 'channel');

-- Dumping structure for table abc_hospital.contact_messages
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dumping data for table abc_hospital.contact_messages: ~2 rows (approximately)
DELETE FROM `contact_messages`;
INSERT INTO `contact_messages` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
	(1, 'client', 'kingsrkingsapumal@gmail.com', 'kjbjhnlkjn', 'hii', '2025-07-21 17:47:27'),
	(2, 'chamod', 'kingsrkingsapumal@gmail.com', 'medical', 'need channel doctor Aravinda ', '2025-07-21 18:07:24'),
	(3, 'sisira kumara', 'chamod@test.com', 'medical', 'medial advice', '2025-07-21 18:12:05');

-- Dumping structure for table abc_hospital.doctors
CREATE TABLE IF NOT EXISTS `doctors` (
  `doctorid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `specialty` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `work_hours` text DEFAULT NULL,
  PRIMARY KEY (`doctorid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dumping data for table abc_hospital.doctors: ~6 rows (approximately)
DELETE FROM `doctors`;
INSERT INTO `doctors` (`doctorid`, `name`, `specialty`, `contact`, `work_hours`) VALUES
	(3, 'Dr. Aravinda rathnayake ', 'Cardiologist', '077 3728422', '9AM to 11AM'),
	(4, 'Dr. Senaka Rajapakse ', 'Neurologist', '07723132445', '3PM to 6PM'),
	(5, 'Dr. Thilak Rajapaksha ', 'Orthopedic Surgeon', '0873546373', '4PM to 7PM\r\n'),
	(6, 'Dr. Udaya Ranawaka ', 'Dermatologist', '085 2234535', '7AM to 10AM'),
	(7, 'Dr. Kumaran Ratnam ', 'Pediatrician', '071 9439934', '6PM to 9PM'),
	(8, 'Dr. Anil Jasinghe ', 'Ophthalmologist', '081 3443535', '2PM to 8PM');

-- Dumping structure for table abc_hospital.patients
CREATE TABLE IF NOT EXISTS `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dumping data for table abc_hospital.patients: ~2 rows (approximately)
DELETE FROM `patients`;
INSERT INTO `patients` (`id`, `full_name`, `email`, `password`) VALUES
	(1, '', 'Aruna@gmail.com', '$2y$10$zPFY6O8VJWb21rUVh4kJ6.Rq/aPl7oy3KYOgWQUmQvA'),
	(2, '', 'pubudu@gmail.comn', '$2y$10$5meURvkm.BLQOLuX8za4vu6VyxBnF6xh8jCB254N5Jb'),
	(3, '', 'chamudi@gmail.com', '$2y$10$XI91LKr54l3/ev3EapyLIuBJX4PVu53O1ZmbxOHnU6u');

-- Dumping structure for table abc_hospital.receptionists
CREATE TABLE IF NOT EXISTS `receptionists` (
  `receptionistid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`receptionistid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `contact` (`contact`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dumping data for table abc_hospital.receptionists: ~3 rows (approximately)
DELETE FROM `receptionists`;
INSERT INTO `receptionists` (`receptionistid`, `name`, `email`, `contact`, `password`) VALUES
	(1, 'Ramodyaa', 'ramodya@mail.com', '077985986', 'password123'),
	(2, 'Gune', 'gune@mail.com', '0766666666', 'gune123'),
	(3, 'Chamod', 'chamod@mail.com', '0777777777', 'chamod123'),
	(4, 'chamod', 'chamod@gmail.com', '24444444445', 'Chamod');

-- Dumping structure for table abc_hospital.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` enum('doctors','receptionists') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- Dumping data for table abc_hospital.users: ~4 rows (approximately)
DELETE FROM `users`;
INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
	(10, 'kumara', 'kumara123', 'receptionists'),
	(11, 'aravinda', 'aravinda123', 'doctors'),
	(12, 'bandara', 'bandara123', 'receptionists'),
	(13, 'Senaka', 'Senaka123', 'doctors'),
	(14, 'Dr. Aravinda rathnayake', 'aravinda123', 'doctors');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
